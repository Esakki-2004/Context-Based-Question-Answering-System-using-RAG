# Acme Corp — Engineering Department Policy (2024)

## 1. Budget Allocation

The Engineering department receives an annual budget of $2,500,000. This budget is split as follows:
- 60% for salaries and contractor fees
- 25% for infrastructure and tooling (cloud, SaaS)
- 15% for research, training, and professional development

Budget overruns beyond 10% must be approved by the CFO in writing.

## 2. Hiring Policy

All new engineering hires must complete:
1. A technical screen (LeetCode-style, 60 minutes)
2. A system design interview
3. A culture-fit interview with HR

Intern hires require approval from the VP of Engineering.

## 3. Remote Work Policy

Engineering employees may work remotely up to 4 days per week. All team members must be on-site every Tuesday for sprint planning. Exceptions require VP approval.

## 4. Project Governance

All projects with a budget exceeding $100,000 must have:
- A written Project Charter signed by the department head
- Bi-weekly status updates to leadership
- A post-mortem within 30 days of completion

The "Platform Rewrite" project is the top priority for FY2024, with a budget of $600,000.

## 5. Code Review Standards

All code must be reviewed by at least one senior engineer before merging to main. PRs should be under 400 lines. Large features must use feature flags.

## 6. Data Privacy

Engineering must comply with GDPR and the company's internal Data Classification Policy. Production databases must never be queried directly by developers without a formal access request approved by the Data Science lead.
